
var schema = require('./../models/entrada.json');

var Validator = require('jsonschema').Validator;

var v = new Validator();  



function autoCorrect(text, correction) {
    Object.keys(correction).forEach((key) => {
        text = text.replaceAll(key, correction[key]);
      });
    return text
    //const reg = new RegExp(Object.keys(correction).join("|"), "g");
    //return text.replace(reg, (matched) => correction[matched]);
}
// Consume the function as follows
    let str = "Helo worLd! Im so glads to be alife in a beautiful worLd.";

const correction = {
    "is not of a type(s)": "não é do tipo",
    number: "numérico",
    worLd: "world",
    glads: "glad",
    alife: "alive",
    Im: "I'm"
};



function validaEntrada(object) {
    //console.log(v.validate(object, schema));
    console.log("========================================================================");
    resultado=v.validate(object,schema);
    texto=resultado.errors.map(e => e.stack).join(". ");
    console.log(texto);
    const correctedText = autoCorrect(texto, correction);
    console.log(correctedText+typeof(correction));    
    //return correctedText
    return resultado
}

module.exports = {validaEntrada}