var express = require('express');
var app = express();
var validador = require("./component/validador.js")

const bp = require('body-parser')
const clone = require('clone');


app.use(bp.json())
app.use(bp.urlencoded({ extended: true }))

app.post('/' , function (req,res){
    const item = req.body
    console.log(req.body);
    const resultado = validador.validaEntrada(item);
    console.log(resultado.valid);
    //console.log(resultado);
    console.log(resultado.errors.map(e => e.stack).join(". "));
    res.send(`Hello!! `+item.nome);
});

const axios = require('axios');

app.get("/",  async function (req,res){
    const dateObject = new Date();
    const year = dateObject.getFullYear();
    const date = (`0${dateObject.getDate()}`).slice(-2);
    const dateStart = (`0${dateObject.getDate()+3}`).slice(-2);
    const dateEnd = (`0${dateObject.getDate()+2}`).slice(-2);
    const month = (`0${dateObject.getMonth() + 1}`).slice(-2);
    
    const response = await axios.get('http://127.0.0.1:3001/ctmdeploy/pegadeploy', {
        headers: {
            'Accept': '*/*',
            'User-Agent': 'Thunder Client (https://www.thunderclient.com)'
        }
    });
    console.log("Aqui");
    item = response.data;
    when = item.When;
    for (let key in item) {
        console.log(key);
        for (let key1 in item[key]) {
            console.log(key1);
        }   
    };
    console.log(item["T2S1_MOD_M3J_AUMENTO-LIMTE"]["T2S1_JOB_M3J_AUMENTO-LIMTE"]["When"].EndDate)
    console.log(`${year}${month}${date}`);
    //console.log(item);
    var itemJob = clone(item["T2S1_MOD_M3J_AUMENTO-LIMTE"]["T2S1_JOB_M3J_AUMENTO-LIMTE"]);
    //var itemJob = Object.assign({},item["T2S1_MOD_M3J_AUMENTO-LIMTE"]["T2S1_JOB_M3J_AUMENTO-LIMTE"]);
    item["T2S1_MOD_M3J_AUMENTO-LIMTE"]["T2S1_JOB_M3J_AUMENTO-LIMTE_FIM"]=itemJob;
    item["T2S1_MOD_M3J_AUMENTO-LIMTE"]["T2S1_JOB_M3J_AUMENTO-LIMTE_FIM"]["When"].EndDate=(`${year}${month}${dateEnd}`);
    item["T2S1_MOD_M3J_AUMENTO-LIMTE"]["T2S1_JOB_M3J_AUMENTO-LIMTE"]["When"].StartDate=(`${year}${month}${dateStart}`);
    res.send(item);

});


app.listen(3000, function(){
    console.log(`App listen on port 3000!`)
});